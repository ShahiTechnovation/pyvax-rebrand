"""Core agent runtime modules."""
