"""Project Classified — Web3-native AI agent runtime for PyVax.

A production-grade agent framework that combines LLM reasoning with
EVM smart contract capabilities via the PyVax Python→EVM toolchain.
"""

__version__ = "0.1.0"
__all__ = ["__version__"]
